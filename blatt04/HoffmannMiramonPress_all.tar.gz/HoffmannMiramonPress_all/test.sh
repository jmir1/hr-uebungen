#! /bin/bash

# printf 'Ergebnisse für den Aufruf \"./partdiff-posix <threads> 2 512 2 2 1024\" für 1 bis 12 Threads:\"\n\n' > results.txt

for t in {3..12}
do
    echo "$t Threads:" >> results.txt
    for r in {1..3}
    do
        echo "Run $r:" >> results.txt
        srun ./partdiff-posix $t 2 512 2 2 1024 | grep Berechnungszeit >> results.txt
    done
    printf '\n\n' >> results.txt
done
